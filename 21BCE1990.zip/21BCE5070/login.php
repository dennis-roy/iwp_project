<?php

$is_invalid = false;

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $mysqli = require __DIR__ . "/database.php";

    $sql = sprintf(
        "SELECT * FROM user
                    WHERE email = '%s'",
        $mysqli->real_escape_string($_POST["email"])
    );

    $result = $mysqli->query($sql);

    $user = $result->fetch_assoc();

    if ($user) {

        if (password_verify($_POST["password"], $user["password_hash"])) {

            session_start();

            session_regenerate_id();

            $_SESSION["user_id"] = $user["id"];

            header("Location: index.php");
            exit;
        }
    }

    $is_invalid = true;
}

?>
<!DOCTYPE html>
<html>

<head>
    <title>Login</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="styles.css" />

</head>

<body>
    <header class="site-header">
        <div class="site-identity">
            <a href="index.php"><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/0/00/PlayStation_logo.svg/400px-PlayStation_logo.svg.png" alt="Site Name" /></a>
            <h1><a href="index.php">Mack's Games</a></h1>
        </div>
        <nav class="site-navigation">
            <ul class="nav">
                <li><a href="about.php">About</a></li>
                <li><a href="login.php">Login</a></li>
                <li><a href="signup.html">Signup</a></li>
            </ul>
        </nav>
    </header>
    </br>
    </br>
    </br>
    <h1>LOGIN</h1>

    <?php if ($is_invalid) : ?>
        <em>Invalid login</em>
    <?php endif; ?>
    </br>
    <form method="post" style="height: 300px;">
        <label for="email">Email</label>
        <input type="email" name="email" id="email" value="<?= htmlspecialchars($_POST["email"] ?? "") ?>">
        </br>
        </br>
        <label for="password">Password</label>
        <input type="password" name="password" id="password">
        </br>
        </br>
        <button>Log in</button>
    </form>
    </br>
    </br>
    </br>
    </br>
    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="company-info">
                    <div class="company-name">
                        <h2>Mack's Games</h2>
                    </div>
                    <div class="contact-address">Address: 2nd Street, Thiruvanmiyur, Chennai - 600209 </div>
                    <div class="contact-email">Email: macksgames@google.com</div>
                    <div class="contact-phone">Phone: +91 9916271892</div>
                    <div class="contact-phone">Instagram: macks_games</div>
                    </br>
                    <div class="contact-phone">&copy; 2024 Mack's Games. All rights reserved</div>
                    </br>
                </div>
            </div>
        </div>
    </footer>
</body>

</html>