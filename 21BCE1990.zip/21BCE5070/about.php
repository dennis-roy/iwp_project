<?php

session_start();

if (isset($_SESSION["user_id"])) {

    $mysqli = require __DIR__ . "/database.php";

    $sql = "SELECT * FROM user
            WHERE id = {$_SESSION["user_id"]}";

    $result = $mysqli->query($sql);

    $user = $result->fetch_assoc();
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page Title</title>
    <link rel="stylesheet" href="styles.css" />
    <script src="products.js"></script>
</head>

<body>
    <header class="site-header">
        <div class="site-identity">
            <a href="index.php"><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/0/00/PlayStation_logo.svg/400px-PlayStation_logo.svg.png" alt="Site Name" /></a>
            <h1><a href="index.php">Mack's Games</a></h1>
        </div>
        <nav class="site-navigation">
            <ul class="nav">
                <li><a href="about.php">About</a></li>
                <?php if (isset($user)) : ?>
                    <li><a href="logout.php">Logout</a></li>
                <?php else : ?>
                    <li><a href="login.php">Login</a></li>
                    <li><a href="signup.html">Signup</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </header>

    <img class="carousel" style="height: 360px;" src=" https://knowtechie.com/wp-content/uploads/2016/03/controllers.jpg">
    </br>
    </br>
    <h1 class="center">ABOUT US</h1>
    </br>
    <p class="center" style="font-size: large; margin-left: 80px; margin-right: 80px;">Welcome to our refurbished video game and console store, where we breathe new life into gaming classics! At our store, we specialize in offering high-quality refurbished video games and consoles at affordable prices. With a passion for gaming and a commitment to sustainability, we carefully restore pre-owned gaming hardware and software to pristine condition. Our extensive inventory includes a wide range of refurbished video game consoles, from retro classics to modern favorites. Whether you're looking for a vintage Nintendo Entertainment System (NES) or a refurbished PlayStation 5 (PS5), we have something for every gamer. Additionally, we offer refurbished handheld consoles like the Game Boy and PSP for gaming on the go.</p>
    </br>
    </br>
    <p class="center" style="font-size: large; margin-left: 80px; margin-right: 80px;">In addition to consoles, we also stock a diverse selection of refurbished video games spanning various genres and platforms. From action-packed adventures to nostalgic favorites, our refurbished games library caters to gamers of all tastes and preferences. Each game undergoes rigorous testing and cleaning to ensure optimal performance and enjoyment. At our store, customer satisfaction is our top priority. Our knowledgeable staff are passionate gamers themselves and are always on hand to assist you in finding the perfect refurbished video game or console to suit your needs. We take pride in providing a welcoming and inclusive environment where gamers can come together to explore, discover, and relive the magic of gaming.</p>
    </br>
    </br>
    <p class="center" style="font-size: large; margin-left: 80px; margin-right: 80px;">Join us at our store and embark on a journey through gaming history with our refurbished video games and consoles. Whether you're a seasoned gamer or new to the world of gaming, we invite you to experience the thrill of gaming classics brought back to life!</p>
    </br>
    </br>
    </br>
    <h1 class="center">OUR HISTORY</h1>
    </br>
    <p class="center" style="font-size: large; margin-left: 80px; margin-right: 80px;">Our refurbished video game and console store has a rich history rooted in our passion for gaming and commitment to providing quality products to gamers worldwide. Established over a decade ago by a group of avid gamers, our store began as a small venture in a local community, fueled by a shared love for gaming and a desire to make gaming accessible to all. Starting with a modest collection of refurbished video games and consoles, we quickly gained a reputation for our dedication to quality and customer satisfaction. As our store grew, so did our inventory and reach. We expanded our selection to include a diverse range of refurbished gaming hardware and software, catering to gamers of all ages and preferences. From retro consoles to the latest releases, our store became a go-to destination for gaming enthusiasts seeking high-quality refurbished products at competitive prices.</p>
    </br>
    </br>
    <p class="center" style="font-size: large; margin-left: 80px; margin-right: 80px;">Over the years, we have remained committed to our core values of integrity, innovation, and customer service. We have adapted to changes in the gaming industry, embracing new technologies and trends while staying true to our roots. Our team of passionate gamers continues to curate our inventory, ensuring that every product we offer meets our high standards of quality and reliability. Today, our store stands as a testament to our enduring dedication to gaming and our community. We take pride in providing a welcoming and inclusive environment where gamers can come together to explore, discover, and share their love for gaming. As we look to the future, we remain committed to our mission of making gaming accessible and enjoyable for all, continuing to uphold the legacy of our humble beginnings while embracing the opportunities that lie ahead.</p>
    </br>
    </br>
    </br>
    </br>
    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="company-info">
                    <div class="company-name">
                        <h2>Mack's Games</h2>
                    </div>
                    <div class="contact-address">Address: 2nd Street, Thiruvanmiyur, Chennai - 600209 </div>
                    <div class="contact-email">Email: macksgames@google.com</div>
                    <div class="contact-phone">Phone: +91 9916271892</div>
                    <div class="contact-phone">Instagram: macks_games</div>
                    </br>
                    <div class="contact-phone">&copy; 2024 Mack's Games. All rights reserved</div>
                    </br>
                </div>
            </div>
        </div>
    </footer>
</body>

</html>