// Function to parse query parameters from URL
function parseQueryParameters() {
    const queryString = window.location.search;
    const urlParams = new URLSearchParams(queryString);
    const product = {
        id: urlParams.get('id'),
        name: urlParams.get('name'),
        description: urlParams.get('description'),
        price: urlParams.get('price'),
        image: urlParams.get('image'),
        banner: urlParams.get('banner'),
        available: urlParams.get('available'),
        detail: urlParams.get('detail')
    };
    return product;
}

function displayProductDetails(product) {
    const productDetailsContainer = document.getElementById('product-details');

    const productTitle = document.getElementById('productTitle').innerHTML = product.name
    const productPrice = document.getElementById('productPrice').innerHTML = `Price: ${product.price}`
    const productDesc = document.getElementById('productDesc').innerHTML = `Description: ${product.description}`
    const productAvail = document.getElementById('productAvail').innerHTML = `Availability: ${product.available}`
    const productImg = document.getElementById('productImage').src = product.image
    const productBanner = document.getElementById('productBanner').src = product.banner
    const productDetail = document.getElementById('productDetail').innerHTML = product.detail

}

window.onload = function () {
    const product = parseQueryParameters();
    displayProductDetails(product);
};
