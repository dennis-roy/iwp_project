<?php

$server = "localhost";
$username = "root";
$password = "";
$db = "login_db";

$mysqli = new mysqli($server, $username, $password, $db);

if ($mysqli->connect_errno) {
    die("Connection error: " . $mysqli->connect_error);
}

return $mysqli;
