<?php

session_start();

if (isset($_SESSION["user_id"])) {

    $mysqli = require __DIR__ . "/database.php";

    $sql = "SELECT * FROM user
            WHERE id = {$_SESSION["user_id"]}";

    $result = $mysqli->query($sql);

    $user = $result->fetch_assoc();
}

?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page Title</title>
    <link rel="stylesheet" href="styles.css" />
    <script src="products.js"></script>
</head>

<body>
    <header class="site-header">
        <div class="site-identity">
            <a href="index.php"><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/0/00/PlayStation_logo.svg/400px-PlayStation_logo.svg.png" alt="Site Name" /></a>
            <h1><a href="index.php">Mack's Games</a></h1>
        </div>
        <nav class="site-navigation">
            <ul class="nav">
                <li><a href="about.php">About</a></li>
                <?php if (isset($user)) : ?>
                    <li><a href="logout.php">Logout</a></li>
                <?php else : ?>
                    <li><a href="login.php">Login</a></li>
                    <li><a href="signup.html">Signup</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </header>

    <div class="carousel-section">
        <div class="carousel-slide">
            <img class="carousel" src="https://a-static.besthdwallpaper.com/the-last-of-us-joel-ellie-wallpaper-2560x800-19850_59.jpg" alt="Image 1">
        </div>
        <div class="carousel-slide">
            <img class="carousel" src="image.png" alt="Image 2">
        </div>
        <div class="carousel-slide">
            <img class="carousel" src="https://4kwallpapers.com/images/wallpapers/god-of-war-ragnarok-kratos-freya-atreus-2022-games-2560x2560-8677.jpg" alt="Image 3">
        </div>
        <div class="carousel-slide">
            <img class="carousel" src="image2.png" alt="Image 4">
        </div>
    </div>
    <script src="carousel.js"></script>

    <div>
        </br>
        </br>
        <h1 class="center">WELCOME TO MACK'S GAMES</h1>
        <p class="center">Where gaming nostalgia meets modern craftsmanship! From vintage consoles to classic video games, we breathe new life into your beloved games. Experience gaming history anew with our expert restoration services and custom upgrades</p>
    </div>



    <h3 class="center">OUR CATALOGUE OF CONSOLES</h3>

    <div id="product-container" class="container"></div>

    <h3 class="center">OUR CATALOGUE OF VIDEO GAMES</h3>

    <div id="game-container" class="container"></div>

    </br>
    </br>
    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="company-info">
                    <div class="company-name">
                        <h2>Mack's Games</h2>
                    </div>
                    <div class="contact-address">Address: 2nd Street, Thiruvanmiyur, Chennai - 600209 </div>
                    <div class="contact-email">Email: macksgames@google.com</div>
                    <div class="contact-phone">Phone: +91 9916271892</div>
                    <div class="contact-phone">Instagram: macks_games</div>
                    </br>
                    <div class="contact-phone">&copy; 2024 Mack's Games. All rights reserved</div>
                    </br>
                </div>
            </div>
        </div>
    </footer>
</body>

</html>