const products = [
    {
        id: 1,
        name: 'PlayStation 4',
        description: 'A refurbished PS4 500GB',
        price: '₹19000',
        image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/Sony-PlayStation-4-PS4-wDualShock-4.jpg/800px-Sony-PlayStation-4-PS4-wDualShock-4.jpg',
        banner: 'https://www.reliancedigital.in/wp-content/uploads/2015/09/Sony-PlayStation-4.jpg',
        available: 'Available in store',
        detail: 'The PlayStation 4 (PS4) revolutionized gaming with its sleek design and powerful hardware, offering stunning graphics and immersive gameplay experiences. With a vast library of games spanning various genres, the PS4 catered to gamers of all preferences. Its DualShock 4 controller introduced innovative features like a touchpad and built-in speaker, enhancing gameplay interactions. The PS4 also doubled as a multimedia entertainment hub, allowing users to stream content and access popular apps. Its online multiplayer platform, PlayStation Network, connected gamers worldwide for competitive and cooperative play. The PS4s longevity and cultural impact cemented its status as an iconic gaming console.Even as newer consoles emerged, the PS4 remains beloved by gamers for its exceptional library and memorable experiences'
    },
    {
        id: 2,
        name: 'Xbox One',
        description: 'A refurbished Xbox One 500GB (No Kinect)',
        price: '₹8000',
        image: 'https://www.gizmochina.com/wp-content/uploads/2023/06/10115705.jpeg',
        banner: 'https://img.redbull.com/images/q_auto,f_auto/redbullcom/2014/06/12/1331658412384_2/xbox-one',
        available: 'Available in store',
        detail: 'The Xbox One redefined entertainment with its powerful hardware and robust features, offering immersive gaming and multimedia experiences. With a diverse lineup of games and backward compatibility support, it caters to gamers of all tastes and preferences. Its innovative controller design and Xbox Live platform provide seamless online gaming and social interaction. The Xbox Ones integration with streaming services and voice control capabilities make it a versatile entertainment hub.Its constant updates and enhancements ensure a dynamic and evolving gaming ecosystem.Despite competition, the Xbox One remains a formidable choice for gamers seeking cutting- edge technology and immersive entertainment.'
    },
    {
        id: 3,
        name: 'PlayStation 2',
        description: 'A refurbished PS2 Slimline',
        price: '₹3400',
        image: 'https://images-cdn.ubuy.co.in/6527a31843e802357136e2b3-restored-playstation-2-ps2-slim-console.jpg',
        banner: 'https://www.lifewire.com/thmb/IW9qm557S9ImCDw5KBPmI8uZEgU=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/ps2-consoles-1253dd15366b448782fda019df6e8e79.jpg',
        available: 'Currently out of stock',
        detail: 'The PlayStation 2 (PS2) revolutionized gaming upon its release in 2000, becoming one of the best-selling consoles of all time. Its sleek design and powerful hardware offered enhanced graphics and gameplay experiences. With a vast library of games spanning various genres, the PS2 catered to gamers of all preferences. Its innovative DualShock 2 controller introduced analog buttons, enhancing precision and control. The PS2 also doubled as a multimedia device, allowing users to play DVDs and CDs. Its longevity and cultural impact cemented its status as an iconic gaming console. Even today, the PS2 remains cherished by gamers worldwide for its timeless classics and nostalgia-inducing experiences.'
    }
];

const games = [
    {
        id: 1,
        name: 'Last of Us: Part 1',
        description: 'A refurbished Last of Us: Part 1 (PS5)',
        price: '₹2700',
        image: 'https://store.playstation.com/store/api/chihiro/00_09_000/container/US/en/99/UP9000-PPSA03396_00-THELASTOFUSPART1/0/image?_version=00_09_000&platform=chihiro&bg_color=000000&opacity=100&w=720&h=720',
        available: 'Currently out of stock',
        banner: 'https://a-static.besthdwallpaper.com/the-last-of-us-joel-ellie-wallpaper-2560x800-19850_59.jpg',
        detail: 'The Last of Us Part 1 is a critically acclaimed action-adventure game released in 2013. Set in a post-apocalyptic world, it follows Joel and Ellies journey across the United States.Renowned for its gripping narrative, emotional depth, and intense gameplay, it explores themes of survival, loss, and redemption.Players navigate through beautifully crafted environments, facing both human and infected enemies. With its compelling characters and cinematic storytelling, it received widespread praise and numerous awards, cementing its status as one of the greatest video games of all time'
    },
    {
        id: 2,
        name: 'Red Dead Redemption 2',
        description: 'A refurbished Red Dead Redemption 2 (PS4)',
        price: '₹1600',
        image: 'https://image.api.playstation.com/cdn/UP1004/CUSA03041_00/3zDubiWo2X5WU18FGiwlsf4lKWb8MwkE.png',
        banner: 'https://wallpapers.com/images/hd/red-dead-redemption-2-desktop-ma5ymivkbs8lzrbj.jpg',
        available: 'Available in store',
        detail: 'Red Dead Redemption 2 is an epic open-world action-adventure game released in 2018. Set in the late 1800s, it follows Arthur Morgan, an outlaw and member of the Van der Linde gang, as they navigate the decline of the Wild West. With stunning graphics and a vast, immersive world, players engage in a variety of activities, from gunfights to horseback riding and fishing. The games rich narrative explores themes of loyalty, morality, and the consequences of ones actions. With its deep characters and attention to detail, "Red Dead Redemption 2" received critical acclaim and became a commercial success, earning numerous awards and accolades'
    },
    {
        id: 3,
        name: 'Halo: The Master Chief Collection',
        description: 'A refurbished Halo: TMCC (Xbox One)',
        price: '₹800',
        image: 'https://4kwallpapers.com/images/wallpapers/halo-the-master-chief-collection-xbox-one-pc-games-master-2048x2048-1759.jpg',
        banner: 'https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/6d01499a-c684-4bbb-986d-7fbe8f66571b/dfpclmy-5d196fca-c572-468f-86e7-df65a3f28ec2.jpg/v1/fill/w_800,h_450,q_75,strp/hd_wallpaper_halo_the_master_chief_collection_seas_by_farmerboy217_dfpclmy-fullview.jpg?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7ImhlaWdodCI6Ijw9NDUwIiwicGF0aCI6IlwvZlwvNmQwMTQ5OWEtYzY4NC00YmJiLTk4NmQtN2ZiZThmNjY1NzFiXC9kZnBjbG15LTVkMTk2ZmNhLWM1NzItNDY4Zi04NmU3LWRmNjVhM2YyOGVjMi5qcGciLCJ3aWR0aCI6Ijw9ODAwIn1dXSwiYXVkIjpbInVybjpzZXJ2aWNlOmltYWdlLm9wZXJhdGlvbnMiXX0.H_jUFrH4MBTsIte8umc_UV6UjxIgBdIGzjXbG1ZPT1s',
        available: 'Available in store',
        detail: 'Halo: The Master Chief Collection is a comprehensive compilation of classic "Halo" games, released in 2014. It features remastered versions of "Halo: Combat Evolved," "Halo 2," "Halo 3," and "Halo 4," along with additional content. Players can experience the iconic campaigns and multiplayer modes across all titles. The collection offers updated graphics and enhanced features, providing both nostalgia and modern gaming experiences. With its extensive content and seamless integration, it serves as the ultimate tribute to the legendary Master Chief and the "Halo" franchise. "Halo: The Master Chief Collection" remains a cornerstone of Xbox gaming, celebrated by fans worldwide'
    },
    {
        id: 4,
        name: 'Ghost of Tsushima',
        description: 'A refurbished Ghost of Tsushima (PS4)',
        price: '₹1200',
        image: 'https://www.suckerpunch.com/wp-content/uploads/2019/12/SQUARE-1024x1024.jpg',
        available: 'Currently out of stock',
        banner: 'https://images5.alphacoders.com/126/1266676.jpg',
        detail: 'Ghost of Tsushima is a critically acclaimed action-adventure game released in 2020. Set in feudal Japan during the Mongol invasion of Tsushima Island, it follows samurai Jin Sakais journey to liberate his homeland.Renowned for its breathtaking visuals, immersive open- world gameplay, and authentic representation of Japanese culture, it captivates players with its stunning landscapes and dynamic combat system.Players can choose to uphold the samurai code or embrace the way of the Ghost, using stealth and guerrilla tactics to defeat their enemies.With its compelling story, rich characters, and seamless exploration, "Ghost of Tsushima" transports players to a captivating world of honor, sacrifice, and redemption'
    },
    {
        id: 5,
        name: 'God of War: Ragnarok',
        description: 'A refurbished God of War: Ragnarok (PS5)',
        price: '₹3200',
        image: 'https://4kwallpapers.com/images/wallpapers/god-of-war-ragnarok-kratos-freya-atreus-2022-games-2560x2560-8677.jpg',
        banner: 'https://wallpapercg.com/download/god-of-war-ragnar%C3%B6k-3840x2160-8636.jpg',
        available: 'Available in store',
        detail: 'God of War: Ragnarok is an upcoming action-adventure game set in the Norse mythology, serving as a direct sequel to 2018s God of War. Continuing the journey of Kratos and his son Atreus, the game explores their quest to confront the Norse gods and prevent the cataclysmic event known as Ragnarok.Players can expect intense combat, immersive storytelling, and breathtaking visuals as they navigate the treacherous realms of Norse mythology.With its rich lore and dynamic characters, God of War: Ragnarok promises to deliver an epic gaming experience that challenges players both emotionally and physically. Fans eagerly anticipate its release, anticipating another masterpiece from the acclaimed development team at Santa Monica Studio'
    },
    {
        id: 6,
        name: 'EA FC24',
        description: 'A refurbished EA FC24 (Xbox One)',
        price: '₹2500',
        image: 'https://pbs.twimg.com/profile_images/1678454262924288024/UPXhNvu3_400x400.jpg',
        banner: 'https://cdn1.epicgames.com/offer/4750c68b2bfa4f43933b81cfd5cc510c/EGS_EASPORTSFC24UltimateEdition_EACanada_Editions_S1_2560x1440-0b83a532d24a60208d592ec2a458375d',
        available: 'Available in store',
        detail: 'EAFC 24 is the latest installment in the acclaimed FIFA video game series, released in 2023. Building upon its predecessors, it delivers enhanced realism and immersive gameplay experiences. With updated graphics and player animations, it offers lifelike representations of football matches. The game features an extensive roster of teams and players from around the world, allowing players to compete in thrilling matches across various leagues and tournaments. Innovative gameplay mechanics and AI improvements ensure strategic depth and challenging competition. Online multiplayer modes enable players to compete against friends or test their skills against the global FIFA community. EAFC 24 continues to be a leading title in the sports gaming genre, capturing the excitement and passion of football fans worldwide.'
    }
];

function generateProductCards() {
    const container = document.getElementById('product-container');

    products.forEach(product => {
        const card = document.createElement('div');
        card.classList.add('card');

        const image = document.createElement('img');
        image.src = product.image;

        const cardContent = document.createElement('div');
        cardContent.classList.add('card-content');

        const title = document.createElement('div');
        title.classList.add('card-title');
        title.textContent = product.name;

        const description = document.createElement('div');
        description.classList.add('card-description');
        description.textContent = product.description;

        const price = document.createElement('div');
        price.classList.add('card-price');
        price.textContent = product.price;

        cardContent.appendChild(title);
        cardContent.appendChild(description);
        cardContent.appendChild(price);

        card.appendChild(image);
        card.appendChild(cardContent);

        container.appendChild(card);

        card.addEventListener('click', function () {
            const queryParams = new URLSearchParams();
            queryParams.append('id', product.id);
            queryParams.append('name', product.name);
            queryParams.append('description', product.description);
            queryParams.append('price', product.price);
            queryParams.append('image', product.image)
            queryParams.append('banner', product.banner)
            queryParams.append('available', product.available)
            queryParams.append('detail', product.detail)

            window.location.href = 'product-details.php?' + queryParams.toString();
        });
    });


    const container2 = document.getElementById('game-container');

    games.forEach(product => {
        const card = document.createElement('div');
        card.classList.add('card');

        const image = document.createElement('img');
        image.src = product.image;

        const cardContent = document.createElement('div');
        cardContent.classList.add('card-content');

        const title = document.createElement('div');
        title.classList.add('card-title');
        title.textContent = product.name;

        const description = document.createElement('div');
        description.classList.add('card-description');
        description.textContent = product.description;

        const price = document.createElement('div');
        price.classList.add('card-price');
        price.textContent = product.price;

        cardContent.appendChild(title);
        cardContent.appendChild(description);
        cardContent.appendChild(price);

        card.appendChild(image);
        card.appendChild(cardContent);

        container2.appendChild(card);

        card.addEventListener('click', function () {
            const queryParams = new URLSearchParams();
            queryParams.append('id', product.id);
            queryParams.append('name', product.name);
            queryParams.append('description', product.description);
            queryParams.append('price', product.price);
            queryParams.append('image', product.image)
            queryParams.append('banner', product.banner)
            queryParams.append('available', product.available)
            queryParams.append('detail', product.detail)

            window.location.href = 'product-details.php?' + queryParams.toString();
        });
    });


}

window.onload = generateProductCards;
